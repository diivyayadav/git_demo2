package Day2;

import java.util.Scanner;

/*
 * 3. Program to replace the spaces of a string with a specific character 
 * Input: String str="Once is a blue moon"; char ch='*' 
 * output: String after replacing spaces with given character: Once*in*a*blue*moon 
 */
public class Prog3 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		String str = scanner.nextLine();
		char ch = scanner.next().charAt(0);

		scanner.close();
		new Prog3().repMethod(str, ch);
	}

	public void repMethod(String str, char ch) {
		String res1 = Character.toString(ch);
		String res2 = str.replace(" ", res1);
		System.out.println(res2);
	}

}
