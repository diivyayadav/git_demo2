package Day2;

/*
 * 5. Text wraping (if a line has so many character make a program to wrap the number of 
 * character to 80 in a line and move the remaining to next line)
 */

public class Prog5 {

	public static void main(String[] args) {
		
	
	String str="Pollution is the process of making the environment pollute the water "
			+ "and the air by adding harmful substances. Pollution causes an imbalance"
			+ " in the environment. ... People have converted the life support system of"
			+ " all living people into their own resources and have greatly disrupted the "
			+ "natural ecological balance.";

	
	new Prog5().wrapChar(str);
	
	}

	public void wrapChar(String str) {
		
		StringBuilder sb = new StringBuilder(str);

		int i = 0;
		while (i + 80 < sb.length() && (i = sb.lastIndexOf(" ", i + 80)) != -1) {
		    sb.replace(i, i + 1, "\n");
		}

		System.out.println(sb.toString());
	}	
}
