package Day2;

/* 4. Program to Find the
* Largest and Smallest Word in a String Input:
* "Hardships often prepare ordinary people for an extraordinary destiny"
* Output: Smallest word: an Largest word: extraordinary
*/

public class Prog4 {
	public static void main(String[] args) {

		String str = "Hardships often prepare ordinary people for an extraordinary destiny";
		String[] arr = str.split(" ");

		new Prog4().find(arr);
		new Prog4().find2(str);
	}

	public void find(String[] arr) {
		String min = arr[0];
		String max = "";
		for (int i = 0; i < arr.length; i++) {
			if (arr[i].length() < min.length()) {
				min = arr[i];
			}
			if (arr[i].length() > max.length()) {
				max = arr[i];
			}
		}
		System.out.println("Smallest word " + min);
		System.out.println("Largest word " + max);
	}

	public void find2(String str) {

		String min = str;
		String max = "";
		int end = 0;
		int start = 0;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == ' ') {
				end = i;
				String res = str.substring(start, end);
				start = end + 1;
				if (res.length() < min.length()) {
					min = res;
				}
				if (res.length() > max.length()) {
					max = res;
				}
			}

		}
		System.out.println("Smallest word using find2 " + min);
		System.out.println("Largest word using find2 " + max);

	}
}
