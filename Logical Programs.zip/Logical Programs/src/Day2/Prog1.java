package Day2;

import java.util.Scanner;

/*1. Program to count the total number of punctuation characters exists in a string
Input: String s= "Good Morning! Mr. Baswaraj Yedrami. Had your breakfast?"
output: Total number of punctuation characters exists in string: 4  */

public class Prog1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter string");
		String str = scanner.nextLine();

		new Prog1().doAction(str);
		scanner.close();
	}

	public void doAction(String str) {

		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == '.' || str.charAt(i) == '!' || str.charAt(i) == '?' || str.charAt(i) == '\\'
					|| str.charAt(i) == '-')
				count++;
		}
		System.out.println(count);

	}
}
