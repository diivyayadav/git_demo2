package Day2;

import java.util.Arrays;

/*2. Program to determine whether two strings are the anagram.(Two Strings are
		 * called the anagram if they contain the same characters. However, the order or
		 * sequence of the characters can be different.) Input : String str1="Grab"
		 * String str2="Brag" output:Both the strings are anagram.*/

public class Prog2 {

	public static void main(String[] args) {

		String str1 = "Grab";
		String str2 = "Brag";

		new Prog2().checkAnagram(str1, str2);

	}

	public void checkAnagram(String str1, String str2) {

		char[] char1 = str1.toLowerCase().toCharArray();
		char[] char2 = str2.toLowerCase().toCharArray();

		Arrays.sort(char1);
		Arrays.sort(char2);

		boolean res = Arrays.equals(char1, char2);

		if (res == true) {
			System.out.println("Both the strings are anagram");

		} else {
			System.out.println("Not anagram");
		}

	}
}